//
//  settingsView.swift
//  travelApp
//
//  Created by Özge Oğuz on 20.12.2023.
//

import SwiftUI

struct settingsView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color(Color(hex: 0xb6cfb6)).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                
                VStack{
                    NavigationLink(destination:ContentView()){
                        
                        Text("Premium Satın Al")
                    }
                    .frame(width: 350, height: 50)
                    .foregroundColor(.white)
                    .background(Color(hex:0xff7373))
                    .cornerRadius(10)
                    
                    NavigationLink(destination:ContentView()){
                        HStack {
                            Image(systemName:"heart.rectangle.fill")
                            Text("Geri Bildirim Gönder")
                        }
                    }
                    .frame(width: 350, height: 50)
                    .foregroundColor(.white)
                    .background(Color(hex:0xff7373))
                    .cornerRadius(10)
                    
                    Link(destination: URL(string: "https://www.tomsoftwares.com")!, label: {
                        Text("Gizlilik Politikası")
                            .frame(width: 350, height: 50)
                            .foregroundColor(.white)
                            .background(Color(hex:0xff7373))
                            .cornerRadius(10)
                    })
                    Link(destination: URL(string: "https://www.tomsoftwares.com")!, label: {
                        Text("Hizmet Şartları")
                            .frame(width: 350, height: 50)
                            .foregroundColor(.white)
                            .background(Color(hex:0xff7373))
                            .cornerRadius(10)
                    })
                    Spacer()
                }
            }.navigationTitle("Settings")
            
        }
    }
}

#Preview {
    settingsView()
}
