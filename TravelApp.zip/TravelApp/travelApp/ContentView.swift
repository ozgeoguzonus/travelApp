//
//  ContentView.swift
//  travelApp
//
//  Created by Özge Oğuz on 20.12.2023.
//

import SwiftUI
#Preview {
    ContentView()
}

extension Color {
    init(hex: Int, opacity: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: opacity
        )
    }
}
struct ContentView: View {
    
    @State var showSheet = false
    @State private var currentStep = 0
    @State private var isSheetPresented = false
    
    let steps: [AnyView] = [
        AnyView(stepOneView()),
        AnyView(stepTwoView()),
        AnyView(stepThreeView())
        // ... Diğer adımları burada ekleyebilirsiniz
    ]
   
    var body: some View {
        NavigationView {
            ZStack{
                Color(Color(hex: 0xb6cfb6)).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                
                VStack{
                    Text("Gösterilecek Seyahat Bulunamadı").foregroundColor(.black)
                        .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(action: {
                                    // Toolbar'a tıklandığında yapılacak işlemler
                                    showSheet.toggle()
                                }) {
                                    Image(systemName: "gear").foregroundColor(.black)
                                }
                            }
                        }
                        .navigationTitle("Seyahatler")
                    
                        .sheet(isPresented: $showSheet) {
                            // Gösterilecek Sheet içeriği buraya gelecek
                            settingsView()
                        }
                    Spacer()
                    Section{
                        Button("Seyahat Oluşturmaya Başla") {
                            isSheetPresented.toggle()
                        }
                        .foregroundColor(.white)
                        .frame(width:300, height: 50)
                        .background(Color(hex: 0xff7373))
                        .cornerRadius(10)
                    }
                    .sheet(isPresented: $isSheetPresented) {
                        NavigationView {
                            steps[currentStep]
                                .navigationBarItems(
                                    trailing: Button("İlerle") {
                                        // Check if there's a next step, and if so, increment the step counter
                                        if currentStep < steps.count - 1 {
                                            currentStep += 1
                                        } else {
                                            // Reset the process if all steps are completed
                                            currentStep = 0
                                            isSheetPresented = false
                                        }
                                    }
                                    
                                )
                        }
                    }
                    }
                }
            }
        }
    }
#Preview {
    ContentView()
}
