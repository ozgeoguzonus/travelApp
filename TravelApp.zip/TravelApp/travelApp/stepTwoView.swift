//
//  stepTwoView.swift
//  travelApp
//
//  Created by Özge Oğuz on 21.12.2023.
//

import SwiftUI

struct stepTwoView: View {
    @State private var birthDate = Date()
    var body: some View {
        ZStack{
            Color(Color(hex: 0xb6cfb6)).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            VStack{
                Section{
                    VStack{
                        Text("Ne Zaman Gideceksiniz?")
                            .frame(width: 360, height: 100,alignment: .leading)
                            .background(Color(hex: 0xb6cfb6))
                            .multilineTextAlignment(.leading)
                        DatePicker("BirthDate",selection: $birthDate)
                            .datePickerStyle(GraphicalDatePickerStyle())
                    }
                }
                Spacer()
            }
        }
    }
}
#Preview {
    stepTwoView()
}
