//
//  stepThreeView.swift
//  travelApp
//
//  Created by Özge Oğuz on 21.12.2023.
//

import SwiftUI

struct stepThreeView: View {
    @State private var borderColors2: [Color] = [Color(hex:0xB6CFB6), Color(hex:0xB6CFB6), Color(hex:0xB6CFB6),Color(hex:0xB6CFB6),Color(hex:0xB6CFB6),Color(hex:0xB6CFB6)]
       var body: some View {
           
           ZStack{
               Color(Color(hex:0xB6CFB6)).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
               
               VStack(spacing:50){
                   
                   Text("Seyahatiniz için bir kategori seçin")
                       .frame(width: 330,height: 70,alignment: .center)
                       .background(.black)
                       .foregroundColor(.white)
                       .font(.headline)
                       .cornerRadius(15)
                   VStack{
                       Button(action: {
                           self.changeButtonColor(index: 0)
                       }) {
                           HStack(){
                               Text("   İş Seyahati")
                               Spacer()
                               Spacer()
                               Spacer()
                               Spacer()
                               Image(systemName: "person.fill")
                               Spacer()
                           }
                           
                           .frame(width: 330,height: 70,alignment: .center)
                           .background(.white)
                           .foregroundColor(.accentColor)
                           .font(.headline)
                           .cornerRadius(15)
                           .overlay(RoundedRectangle(cornerRadius: 8).stroke(borderColors2[0], lineWidth: 2))
                           
                           
                       }
                       Button(action: {
                           self.changeButtonColor(index: 1)
                       }) {
                           HStack{
                               Text("   Şehir Turu")
                               Spacer()
                               Spacer()
                               Spacer()
                               Spacer()
                               Image(systemName: "suitcase.cart.fill")
                               Spacer()
                           }
                           .frame(width: 330,height: 70,alignment: .center)
                           .background(.white)
                           .foregroundColor(.accentColor)
                           .font(.headline)
                           .cornerRadius(15)
                           .overlay(RoundedRectangle(cornerRadius: 8).stroke(borderColors2[1], lineWidth: 2))
                       }
                       Button(action: {
                           self.changeButtonColor(index: 2)
                       }) {
                           HStack{
                               Text("   Plaj Tatili")
                               Spacer()
                               Spacer()
                               Spacer()
                               Spacer()
                               Image(systemName: "suitcase.cart.fill")
                               Spacer()
                           }
                           .frame(width: 330,height: 70,alignment: .center)
                           .background(.white)
                           .foregroundColor(.accentColor)
                           .font(.headline)
                           .cornerRadius(15)
                           .overlay(RoundedRectangle(cornerRadius: 8).stroke(borderColors2[2], lineWidth: 2))
                       }
                       Button(action: {
                           self.changeButtonColor(index: 3)
                       }) {
                           HStack{
                               Text("   Kamp")
                               Spacer()
                               Spacer()
                               Spacer()
                               Spacer()
                               Image(systemName: "suitcase.cart.fill")
                               Spacer()
                           }
                           .frame(width: 330,height: 70,alignment: .center)
                           .background(.white)
                           .foregroundColor(.accentColor)
                           .font(.headline)
                           .cornerRadius(15)
                           .overlay(RoundedRectangle(cornerRadius: 8).stroke(borderColors2[3], lineWidth: 2))
                       }
                       Button(action: {
                           self.changeButtonColor(index: 4)
                       }) {
                           HStack{
                               Text("   Yılbaşı")
                               Spacer()
                               Spacer()
                               Spacer()
                               Spacer()
                               Image(systemName: "suitcase.cart.fill")
                               Spacer()
                           }
                           .frame(width: 330,height: 70,alignment: .center)
                           .background(.white)
                           .foregroundColor(.accentColor)
                           .font(.headline)
                           .cornerRadius(15)
                           .overlay(RoundedRectangle(cornerRadius: 8).stroke(borderColors2[4], lineWidth: 2))
                       }
                       Button(action: {
                           self.changeButtonColor(index: 5)
                       }) {
                           HStack{
                               Text("   Diğer")
                               Spacer()
                               Spacer()
                               Spacer()
                               Spacer()
                               Image(systemName: "cat.fill")
                               Spacer()
                           }
                           .frame(width: 330,height: 70,alignment: .center)
                           .background(.white)
                           .foregroundColor(.accentColor)
                           .font(.headline)
                           .cornerRadius(15)
                           .overlay(RoundedRectangle(cornerRadius: 8).stroke(borderColors2[5], lineWidth: 2))
                       }
                   }
               }
               
           }
           
       }
       
       func changeButtonColor(index: Int){
           var updatedColors = [Color]()
                 for i in 0..<borderColors2.count {
                     if i == index {
                         updatedColors.append(Color.red)
                     } else {
                         updatedColors.append(Color(hex:0xB6CFB6))
                     }
                 }
                 borderColors2 = updatedColors
             }
           
               
       }


#Preview {
    stepThreeView()
}
