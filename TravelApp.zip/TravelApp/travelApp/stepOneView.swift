//
//  stepOneView.swift
//  travelApp
//
//  Created by Özge Oğuz on 21.12.2023.
//

import SwiftUI

struct stepOneView: View {
    @State private var sehirAd: String = ""
       var body: some View {
           NavigationView{
               ZStack{
                   Color(Color(hex: 0xb6cfb6)).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                   VStack{
                       Section{
                           VStack{
                               Text("Nereye Gideceksiniz?")
                                   .multilineTextAlignment(.leading)
                                   .frame(width: 300,height: 30,alignment: .topLeading)
                                   .cornerRadius(10)
                                   .foregroundColor(.white)
                               TextField("Seçiniz", text: $sehirAd)
                                   .multilineTextAlignment(.leading)
                                   .frame(width: 300,height: 35)
                                   .cornerRadius(10)
                                   .foregroundColor(.white)
                           }
                           .frame(width:330,height: 120)
                           .background(.gray)
                           .cornerRadius(20)
                           
                       }
                       
                       Spacer()
                   }
               }
           }
     }
    }

#Preview {
    stepOneView()
}
