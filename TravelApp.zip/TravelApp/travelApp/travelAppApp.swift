//
//  travelAppApp.swift
//  travelApp
//
//  Created by Özge Oğuz on 20.12.2023.
//

import SwiftUI

@main
struct travelAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
